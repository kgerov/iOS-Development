//
//  DataReloadable.swift
//  OnTheMap
//
//  Created by Konstantin Gerov on 8/13/16.
//  Copyright © 2016 Konstantin Gerov. All rights reserved.
//

protocol DataReloadable {
    
    func reloadStudentLocations() -> Void
}
