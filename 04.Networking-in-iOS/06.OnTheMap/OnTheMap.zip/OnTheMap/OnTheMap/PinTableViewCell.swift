//
//  PinTableViewCell.swift
//  OnTheMap
//
//  Created by Konstantin Gerov on 8/10/16.
//  Copyright © 2016 Konstantin Gerov. All rights reserved.
//

import UIKit

class PinTableViewCell : UITableViewCell {
    
    @IBOutlet weak var studentName: UILabel!
}
